
export type NetworkType = 'plain' | 'resnet';
